//
//  ShareZoneApp.swift
//  ShareZone
//
//  Created by user on 3/12/2023.
//

import SwiftUI
import Firebase

@main
struct ShareZoneApp: App {
    
    @StateObject var viewModel = AuthViewModel()
    
    init() {
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            NavigationView {
                ContentView()
            }.environmentObject(viewModel)
        }
    }
}
