//
//  Twinkle.swift
//  ShareZone
//
//  Created by user on 10/12/2023.
//

import Firebase
import FirebaseDatabase
import FirebaseFirestoreSwift

struct Twinkle: Identifiable, Decodable {
    @DocumentID var id: String?
    let caption: String
    let timestamp: Timestamp
    let uid: String
    var stars: Int
    
    var user: User?
    var didStar: Bool? = false
    
    var timestampString: String {
        return timestamp.dateValue().timestampString()
    }
}
