//
//  ProfileViewModel.swift
//  ShareZone
//
//  Created by user on 18/12/2023.
//

import Foundation

class ProfileViewModel: ObservableObject {
    @Published var twinkles = [Twinkle]()
    @Published var starredTwinkles = [Twinkle]()
    private let service = TwinkleService()
    private let userService = UserService()
    let user: User
    
    init(user: User) {
        self.user = user
        self.fetchUserTwinkles()
        self.fetchStarredTwinkles()
    }
    
    var actionButtonTitle: String {
        return user.isCurrentUser ? "My Share Zone" : "Welcome"
    }
    
    func twinkles(forFilter filter: TwinkleFilterViewModel) -> [Twinkle] {
        switch filter {
        case .twinkles:
            return twinkles
        
        case .sparkles:
            return starredTwinkles
        }
    }
    
    func fetchUserTwinkles() {
        guard let uid = user.id else { return }
        service.fetchTwinkles(forUid: uid) { twinkles in
            self.twinkles = twinkles
            
            for i in 0 ..< twinkles.count {
                self.twinkles[i].user = self.user
            }
        }
    }
    
    func fetchStarredTwinkles() {
        guard let uid = user.id else { return }
        service.fetchStarredTwinkles(forUid: uid) { twinkles in
            self.starredTwinkles = twinkles
            
            for i in 0 ..< twinkles.count {
                let uid = twinkles[i].uid
                
                self.userService.fetchUser(withUid: uid) { user in
                    self.starredTwinkles[i].user = user
                        
                }
            }
        }

    }
    
}
