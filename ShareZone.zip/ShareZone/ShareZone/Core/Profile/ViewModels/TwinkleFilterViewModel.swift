//
//  TwinkleFilterViewModel.swift
//  ShareZone
//
//  Created by user on 9/12/2023.
//

import Foundation

enum TwinkleFilterViewModel: Int, CaseIterable {
    case twinkles
    
    case sparkles
    
    var title: String {
        switch self {
        case .twinkles: return "Twinkles"
        
        case .sparkles: return "Sparkles"
        }
    }
}
