//
//  NewTwinkleView.swift
//  ShareZone
//
//  Created by user on 11/12/2023.
//

import SwiftUI
import Kingfisher

struct NewTwinkleView: View {
    @State private var caption = ""
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var authViewModel: AuthViewModel
    @ObservedObject var viewModel = UploadTwinkleViewModel()
    
    var body: some View {
        VStack {
            HStack {
                Button {
                    presentationMode.wrappedValue.dismiss()
                } label: {
                    Text("Cancel")
                        .foregroundColor(Color(.systemTeal))
                }
                Spacer()
                
                Button {
                    viewModel.uploadTwinkle(withCaption: caption)
                } label: {
                    Text("Twinkle")
                        .bold()
                        .padding(.horizontal)
                        .padding(.vertical, 8)
                        .background(Color(.systemMint))
                            .foregroundColor(.white)
                            .clipShape(Capsule())
                }

            }.padding()
            
            HStack(alignment: .top) {
                if let user = authViewModel.currentUser {
                    KFImage(URL(string: user.profileImageUrl))
                        .resizable()
                        .scaledToFill()
                        .clipShape(Circle())
                        .frame(width: 64, height: 64)
                }
                
                TextArea("Share New Twinkle", text: $caption)
            }.padding()
        }.onReceive(viewModel.$didUploadTwinkle) { success in
            if success {
                presentationMode.wrappedValue.dismiss()
            }
        }
    }
}

#Preview {
    NewTwinkleView()
}
