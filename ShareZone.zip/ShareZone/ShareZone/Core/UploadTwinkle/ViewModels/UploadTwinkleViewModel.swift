//
//  UploadTwinkleViewModel.swift
//  ShareZone
//
//  Created by user on 11/12/2023.
//

import Foundation

class UploadTwinkleViewModel: ObservableObject {
    @Published var didUploadTwinkle = false
    let service = TwinkleService()
    
    func uploadTwinkle(withCaption caption: String) {
        service.uploadTwinkle(caption: caption) { success in
            if success {
                self.didUploadTwinkle = true
            } else {
                
            }
            
        }
    }
}
