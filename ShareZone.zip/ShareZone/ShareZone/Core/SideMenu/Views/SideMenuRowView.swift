//
//  SideMenuRowView.swift
//  ShareZone
//
//  Created by user on 11/12/2023.
//

import SwiftUI

struct SideMenuRowView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    SideMenuRowView()
}
