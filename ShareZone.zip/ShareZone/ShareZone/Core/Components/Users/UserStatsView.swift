//
//  UserStatsView.swift
//  ShareZone
//
//  Created by user on 3/12/2023.
//

import SwiftUI

struct UserStatsView: View {
    var body: some View {
        HStack(spacing: 28) {
            HStack(spacing: 4) {
                Text(" ")
                    .font(.subheadline)
                    .bold()
                
                Text(" ")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            
            HStack(spacing: 4) {
                Text(" ")
                    .font(.subheadline)
                    .bold()
                
                Text(" ")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
        }
    }
}

#Preview {
    UserStatsView()
}
