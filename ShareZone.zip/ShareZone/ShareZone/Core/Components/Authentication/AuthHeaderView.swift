//
//  AuthHeaderView.swift
//  ShareZone
//
//  Created by user on 4/12/2023.
//

import SwiftUI

struct AuthHeaderView: View {
    let title1: String
    let title2: String
    var body: some View {
        VStack(alignment: .leading) {
            HStack { Spacer() }
            Text(title1)
                .font(.largeTitle)
                .fontWeight(.bold)
            
            Text(title2)
                .font(.largeTitle)
                .fontWeight(.semibold)
            
        }.frame(height: 200)
            .padding(.leading)
            .background(Color(.systemMint))
            .foregroundColor(.white)
            .clipShape(RoundedShape(corners: [.bottomLeft, .bottomRight]))
            .shadow(color: .mint.opacity(0.5), radius: 10, x: 0, y: 0)

    }
}

#Preview {
    AuthHeaderView(title1: "Share Zone", title2: "Twinkle and Sparkle")
}
