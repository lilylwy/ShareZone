//
//  RoundedShape.swift
//  ShareZone
//
//  Created by user on 4/12/2023.
//

import SwiftUI

struct RoundedShape: Shape {
    var corners: UIRectCorner
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: 60, height: 60))
        
        return Path(path.cgPath)
    }
}
