//
//  TwinkleRowViewModel.swift
//  ShareZone
//
//  Created by user on 17/12/2023.
//

import Foundation

class TwinkleRowViewModel: ObservableObject {
    @Published var twinkle: Twinkle
    private let service = TwinkleService()
    
    init(twinkle: Twinkle) {
        self.twinkle = twinkle
        checkIfUserStarredTwinkle()
    }
    
    func starTwinkle() {
        service.starTwinkle(twinkle) {
            self.twinkle.didStar = true
            
        }
    }
    
    func unstarTwinkle() {
        service.unstarTwinkle(twinkle) {
            self.twinkle.didStar = false
        }
    }
    
    func checkIfUserStarredTwinkle() {
        service.checkIfUserStarredTwinkle(twinkle) { didStar in
            if didStar {
                self.twinkle.didStar = true
            }
        }
    }
}
