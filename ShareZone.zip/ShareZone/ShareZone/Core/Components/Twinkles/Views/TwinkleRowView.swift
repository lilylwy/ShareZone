//
//  TwinkleRowView.swift
//  ShareZone
//
//  Created by user on 6/12/2023.
//

import SwiftUI
import Kingfisher

struct TwinkleRowView: View {
    @ObservedObject var viewModel: TwinkleRowViewModel
    
    init(twinkle: Twinkle) {
        self.viewModel = TwinkleRowViewModel(twinkle: twinkle)
    }
    var body: some View {
        
        VStack(alignment: .leading) {
            //user profile & info & twinkle
            if let user = viewModel.twinkle.user {
                HStack(alignment: .top, spacing: 12) {
                    KFImage(URL(string: user.profileImageUrl))
                        .resizable()
                        .scaledToFill()
                        .frame(width: 56, height: 56)
                        .foregroundColor(Color(.systemMint))
                        .clipShape(Circle())
                    
                    // user info & twinkle
                    VStack(alignment: .leading, spacing: 4) {
                        //user info
                        
                            HStack {
                                Text(user.fullname)
                                    .font(.subheadline).bold()
                                
                                Text("@\(user.username)")
                                    .foregroundColor(.gray)
                                    .font(.caption)
                                
                                Text(viewModel.twinkle.timestampString)
                                    .foregroundColor(.gray)
                                    .font(.caption)
                                
                            }
                        
                        //Twinkle
                        Text(viewModel.twinkle.caption)
                            .font(.subheadline)
                            .multilineTextAlignment(.leading)
                    }
                }
            }
            //action buttons
            HStack {
                Spacer()
                Button {
                    viewModel.twinkle.didStar ?? false ?
                    viewModel.unstarTwinkle() :
                    viewModel.starTwinkle()
                } label: {
                    Image(systemName: viewModel.twinkle.didStar ?? false ? "star.fill" : "star")
                        .font(.subheadline)
                        .foregroundColor(viewModel.twinkle.didStar ?? false ? .yellow : .teal)
                }.imageScale(.large)
                
                
            }.padding()
            
            Divider()
        }.padding()
    }
}

/**struct TwinkleRowView_Previews: PreviewProvider {
    static var previews: some View {
        TwinkleRowView()
    }
}**/
    
    

