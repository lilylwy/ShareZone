//
//  MessagesView.swift
//  ShareZone
//
//  Created by user on 9/12/2023.
//

import SwiftUI

struct MessagesView: View {
    var body: some View {
        Text("Messages")
    }
}

#Preview {
    MessagesView()
}
