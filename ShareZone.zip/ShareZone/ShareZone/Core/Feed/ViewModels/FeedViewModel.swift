//
//  FeedViewModel.swift
//  ShareZone
//
//  Created by user on 14/12/2023.
//

import Foundation

class FeedViewModel: ObservableObject {
    @Published var twinkles = [Twinkle]()
    let service = TwinkleService()
    let userService = UserService()
    
    init() {
        fetchTwinkles()
    }
    
    func fetchTwinkles() {
        service.fetchTwinkles { twinkles in
            self.twinkles = twinkles
            
            for i in 0 ..< twinkles.count {
                let uid = twinkles[i].uid
                
                self.userService.fetchUser(withUid: uid) { user in
                    self.twinkles[i].user = user
                        
                }
            }
            
            
        }
        
    }
}


