//
//  NotificationsView.swift
//  ShareZone
//
//  Created by user on 5/12/2023.
//

import SwiftUI

struct NotificationsView: View {
    var body: some View {
        Text("Notifications")
    }
}

#Preview {
    NotificationsView()
}
