//
//  LoginView.swift
//  ShareZone
//
//  Created by user on 4/12/2023.
//

import SwiftUI
import LocalAuthentication

struct LoginView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var unlocked = false
    @State private var text = "Sign In with Face ID"
    @EnvironmentObject var viewModel: AuthViewModel
    var body: some View {
        VStack {
            AuthHeaderView(title1: "Share Zone", title2: "Twinkle and Sparkle")
            
            VStack(spacing: 70) {
                CustomInputField(imageName: "envelope", placeholderText: "Email", text: $email)
                
                CustomInputField(imageName: "lock",
                                 placeholderText: "Password",
                                 isSecureField: true,
                                 text: $password)
            }.padding(.horizontal, 32)
                .padding(.top, 70)
            
            HStack {
                Spacer()
                
                

            }
            Spacer()
            Button(text) {
                            authenticate()
                        }.foregroundColor(Color(.systemTeal))
                            .font(.system(size: 24))

            
            Spacer()
            NavigationLink {
                RegistrationView()
                    .navigationBarHidden(true)
            } label: {
                HStack {
                    Text("No account?")
                        .font(.body)
                    
                    Text("Sign Up")
                        .font(.body)
                        .fontWeight(.semibold)
                }
            }.padding(.bottom, 32)
                .foregroundColor(Color(.systemTeal))
            Spacer()

            
        }.ignoresSafeArea()
            .navigationBarHidden(true)
    }
    func authenticate() {
            let context = LAContext()
            var error: NSError?

            if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
                context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: "Face ID") {
                    success, authenticationError in
                    if success {
                        viewModel.login(withEmail: email, password: password)
                    } else {
                        text = "Sign In with Face ID"
                    }
                }
            }
        }
}

#Preview {
    LoginView()
}
