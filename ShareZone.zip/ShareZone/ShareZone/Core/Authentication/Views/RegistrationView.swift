//
//  RegistrationView.swift
//  ShareZone
//
//  Created by user on 4/12/2023.
//

import SwiftUI

struct RegistrationView: View {
    @State private var email = ""
    @State private var username = ""
    @State private var fullname = ""
    @State private var password = ""
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var viewModel: AuthViewModel
    var body: some View {
        VStack {
            
            NavigationLink(destination: ProfilePicSelectorView(),
                           isActive: $viewModel.didAuthenticateUser,
                           label: {})
            
            AuthHeaderView(title1: "Share Zone", title2: "Create an Account")
            
            VStack(spacing: 70) {
                CustomInputField(imageName: "envelope", placeholderText: "Email", text: $email)
                
                CustomInputField(imageName: "person", placeholderText: "Username", text: $username)
                
                CustomInputField(imageName: "person.text.rectangle", placeholderText: "Fullname", text: $fullname)
                
                CustomInputField(imageName: "lock",
                                 placeholderText: "Password",
                                 isSecureField: true,
                                 text: $password)
            }.padding(.horizontal, 32)
                .padding(.top, 70)
            
            Spacer()
            Button {
                viewModel.register(withEmail: email, password: password, fullname: fullname, username: username)
            } label: {
                Text("Sign Up")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 340, height: 50)
                    .background(Color(.systemMint))
                    .clipShape(Capsule())
                    .padding()
            }.shadow(color: .mint.opacity(0.5), radius: 10, x: 0, y: 0)
            
            Spacer()
            
            Button {
                presentationMode.wrappedValue.dismiss()
            } label: {
                HStack {
                    Text("Have an account?")
                        .font(.body)
                    
                    Text("Sign In")
                        .font(.body)
                        .fontWeight(.semibold)
            }
            }.padding(.bottom, 32)
                .foregroundColor(Color(.systemTeal))


        }.ignoresSafeArea()
    }
}

#Preview {
    RegistrationView()
}
