//
//  ProfilePicSelectorView.swift
//  ShareZone
//
//  Created by user on 5/12/2023.
//

import SwiftUI

struct ProfilePicSelectorView: View {
    @State private var showImagePicker = false
    @State private var selectedImaage: UIImage?
    @State private var profileImage: Image?
    @EnvironmentObject var viewModel: AuthViewModel
    var body: some View {
        VStack {
            AuthHeaderView(title1: "Share Zone",
                           title2: "Select a Profile Pic")
            
            Button {
                showImagePicker.toggle()
            } label: {
                if let profileImage = profileImage {
                    profileImage
                        .resizable()
                        .modifier(ProfileImageModifier())
                } else {
                    Image(systemName: "photo")
                        .resizable()
                        .renderingMode(.template)
                        .modifier(ProfileImageModifier())
                }
                
            }
            .sheet(isPresented: $showImagePicker, onDismiss: loadImage) {
                ImagePicker(selectedImage: $selectedImaage)
            }.padding(.top, 80)
            Spacer()
            
            if let selectedImaage = selectedImaage {
                Button {
                    viewModel.uploadProfileImage(selectedImaage)
                } label: {
                    Text("Finish")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(width: 340, height: 50)
                        .background(Color(.systemMint))
                        .clipShape(Capsule())
                        .padding()
                }.shadow(color: .mint.opacity(0.5), radius: 10, x: 0, y: 0)
            }
                
            
            Spacer()
        }.ignoresSafeArea()
    }
    
    func loadImage() {
        guard let selectedImage = selectedImaage else { return }
        profileImage = Image(uiImage: selectedImage)
    }
}

private struct ProfileImageModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .foregroundColor(Color(.systemMint))
            .scaledToFill()
            .frame(width: 200, height: 200)
            .clipShape(Circle())
    }
}

#Preview {
    ProfilePicSelectorView()
}
