//
//  TwinkleService.swift
//  ShareZone
//
//  Created by user on 15/12/2023.
//

import Firebase

struct TwinkleService {
     
    func uploadTwinkle(caption: String, completion: @escaping(Bool) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        
        let data = ["uid": uid, "caption": caption, "stars": 0, "timestamp": Timestamp(date: Date())] as [String : Any]
        
        Firestore.firestore().collection("twinkles").document()
            .setData(data) { error in
                if let error = error {
                    print("DEBUG: Failed to upload twinkle with error: \(error.localizedDescription)")
                    completion(false)
                    return
                }
                
                completion(true)
            }
    }
    
    func fetchTwinkles(completion: @escaping([Twinkle]) -> Void) {
        Firestore.firestore().collection("twinkles")
            .order(by: "timestamp", descending: true)
            .getDocuments() { snapshot, _ in
            guard let documents = snapshot?.documents else { return }
            let twinkles = documents.compactMap({ try? $0.data(as: Twinkle.self)})
            completion(twinkles)
            }
    }
    
    func fetchTwinkles(forUid uid: String, completion: @escaping([Twinkle]) -> Void) {
        Firestore.firestore().collection("twinkles")
            .whereField("uid", isEqualTo: uid)
            .getDocuments() { snapshot, _ in
            guard let documents = snapshot?.documents else { return }
            let twinkles = documents.compactMap({ try? $0.data(as: Twinkle.self)})
                completion(twinkles.sorted(by: { $0.timestamp.dateValue() > $1.timestamp.dateValue()}))
            }
    }
    
}

extension TwinkleService {
    func starTwinkle(_ twinkle: Twinkle, completion: @escaping() -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard let twinkleId = twinkle.id else { return }
        
        let userStarsRef = Firestore.firestore().collection("users").document(uid).collection("user-stars")
        
        Firestore.firestore().collection("twinkles").document(twinkleId)
            .updateData(["stars": twinkle.stars + 1]) { _ in
                userStarsRef.document(twinkleId).setData([:]) { _ in
                    completion()
                }
            }
    }
    
    func unstarTwinkle(_ twinkle: Twinkle, completion: @escaping() -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard let twinkleId = twinkle.id else { return }
        guard twinkle.stars > 0 else { return }
        
        let userStarsRef = Firestore.firestore().collection("users").document(uid).collection("user-stars")
        
        Firestore.firestore().collection("twinkles").document(twinkleId)
            .updateData(["stars": twinkle.stars - 1]) { _ in
                userStarsRef.document(twinkleId).delete { _ in
                    completion()
                }
            }
    }
    
    func checkIfUserStarredTwinkle(_ twinkle: Twinkle, completion: @escaping(Bool) -> Void) {
        guard let uid = Auth.auth().currentUser?.uid else { return }
        guard let twinkleId = twinkle.id else { return }
        
        Firestore.firestore().collection("users").document(uid).collection("user-stars").document(twinkleId).getDocument { snapshot, _ in
            guard let snapshot = snapshot else { return }
            completion(snapshot.exists)
        }
    }
    
    func fetchStarredTwinkles(forUid uid: String, completion: @escaping([Twinkle]) -> Void) {
        var twinkles = [Twinkle]()
        Firestore.firestore().collection("users")
            .document(uid)
            .collection("user-stars")
            .getDocuments { snapshot, _ in
                guard let documents = snapshot?.documents else { return }
                
                documents.forEach { doc in
                    let twinkleID = doc.documentID
                    
                    Firestore.firestore().collection("twinkles")
                        .document(twinkleID)
                        .getDocument { snapshot, _ in
                            guard let twinkle = try? snapshot?.data(as: Twinkle.self) else { return }
                            twinkles.append(twinkle)
                            
                            completion(twinkles)
                    }
                }
            }
    }
    
}
